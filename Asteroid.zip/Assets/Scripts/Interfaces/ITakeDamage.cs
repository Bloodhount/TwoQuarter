

public interface ITakeDamage
{
    // TODO: create some method
}
