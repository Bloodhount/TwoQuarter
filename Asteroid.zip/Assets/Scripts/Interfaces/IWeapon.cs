public interface IWeapon
{
    void Shoot(float shootForce);
}
