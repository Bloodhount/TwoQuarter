
public interface IMakeDamage 
{
    // TODO: create some method
}
