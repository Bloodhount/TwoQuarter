using UnityEngine;


public interface IRotation
{
    void Rotation(Vector3 direction);
}

