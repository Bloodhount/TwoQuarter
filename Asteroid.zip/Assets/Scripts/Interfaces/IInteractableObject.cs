using UnityEngine;

public class IInteractableObject : MonoBehaviour
{

}
