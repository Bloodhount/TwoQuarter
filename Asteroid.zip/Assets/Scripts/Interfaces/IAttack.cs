using UnityEngine;
public interface IAttack
{
    public void UniversalAttack();
    public void UniversalAttack(Vector3 position);
}

