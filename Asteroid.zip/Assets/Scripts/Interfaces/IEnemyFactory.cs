using Asteroids;

public interface IEnemyFactory
{
    Enemy Create(EnemyHealth health);
}

