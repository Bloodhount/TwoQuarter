public interface IShipState
{
    void StateOn();
    void StateOff();
}
